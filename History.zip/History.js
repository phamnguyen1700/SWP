import React, { useState, useEffect } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';
import './History.css';
import axios from 'axios';
import { useAuth } from '../authcontext';
import StaffNav from './StaffNav';
import DashboardNav from '../dashboard/dashboardContent/DashboardNav';

const History = () => {
    const [combinedData, setCombinedData] = useState([]);
    const { user } = useAuth();

    useEffect(() => {
        async function fetchData() {
            try {
                // Fetch all orders
                const orderResponse = await axios.get('https://localhost:7251/api/Orders');
                const orders = orderResponse.data;

                // Fetch all payments
                const paymentResponse = await axios.get('https://localhost:7251/api/Payment');
                const payments = paymentResponse.data;

                // Combine orders with their corresponding payments
                const combinedData = orders.map(order => {
                    const payment = payments.find(p => p.orderId === order.orderId);
                    return {
                        ...order,
                        paymentDetails: payment,
                    };
                });

                console.log('Combined Data:', combinedData); // Log the combined data for debugging
                setCombinedData(combinedData);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        }

        fetchData();
    }, []);

    return (
        <div className="container-fluid">
            <div>
                {user && user.roleId === 3 ? (
                    <StaffNav />
                ) : (
                    <DashboardNav />
                )}
            </div>
            <div className='container-fluid-2'>
                <TableContainer component={Paper} className="table-container">
                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableCell align="center" className="table-head-cell">Order ID</TableCell>
                                <TableCell align="center" className="table-head-cell">Total Price ($)</TableCell>
                                <TableCell align="center" className="table-head-cell">Deposit ($)</TableCell>
                                <TableCell align="center" className="table-head-cell">Amount Paid ($)</TableCell>
                                <TableCell align="center" className="table-head-cell">Date Paid</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {combinedData.map((order, index) => (
                                <React.Fragment key={index}>
                                    <TableRow>
                                        <TableCell align="center" className="table-cell">{order.orderId}</TableCell>
                                        <TableCell align="center" className="table-cell">{order.totalPrice.toFixed(2)}</TableCell>
                                        <TableCell align="center" className="table-cell">{order.paymentDetails?.deposit.toFixed(2) || 'N/A'}</TableCell>
                                        <TableCell align="center" className="table-cell">{order.paymentDetails?.amountPaid.toFixed(2) || 'N/A'}</TableCell>
                                        <TableCell align="center" className="table-cell">{order.paymentDetails?.datePaid || 'N/A'}</TableCell>
                                    </TableRow>
                                </React.Fragment>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </div>
        </div>
    );
};

export default History;
